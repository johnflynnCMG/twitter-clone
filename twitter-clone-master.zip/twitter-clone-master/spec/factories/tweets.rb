FactoryGirl.define do
  factory :tweet do
    tweet_text "MyString"
user nil
location "MyString"
  end

end
