FactoryGirl.define do
  factory :favorite do
    tweet nil
user nil
  end

end
