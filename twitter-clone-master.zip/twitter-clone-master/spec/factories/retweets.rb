FactoryGirl.define do
  factory :retweet do
    user nil
tweet nil
  end

end
