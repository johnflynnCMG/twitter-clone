require 'rails_helper'

RSpec.describe TweetsController, :type => :controller do

end
