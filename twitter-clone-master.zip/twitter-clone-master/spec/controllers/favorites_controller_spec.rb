require 'rails_helper'

RSpec.describe FavoritesController, :type => :controller do

end
