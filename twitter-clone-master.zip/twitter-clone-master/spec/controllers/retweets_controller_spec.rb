require 'rails_helper'

RSpec.describe RetweetsController, :type => :controller do

end
