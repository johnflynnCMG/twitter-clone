require 'rails_helper'

RSpec.describe FindFriendsController, :type => :controller do

end
