require 'rails_helper'

RSpec.describe RelationshipsController, :type => :controller do

end
